This process will Install a Bastion server running dns services via dnsmasq and a three node OCP cluster on bare metal. 
Further it will configure HAProxy load balancer for the Cluster and then install Fusion. 


Install Prereqs for Bastion. 



git clone for fusion build

cd into the fusion-dir
chmod +x *.sh

run the # 1-ssh-key.sh   			    # this will create the ssh key needed to trust bastion into OCP built servers
run the # 2A-install-prereqs-for-ocp-on-libvirt.sh  # This installs prereqs for libvirt if desired
run the # 2B-create-host-bridge.sh 		    # If you want to create a host bridge for the Lan interface
run the # 2C-fusion-prereqs.sh           		    # This installs the prereqs for OCP and Fusion


Install dnsmasq on Bastion server
# mkdir /software
# dnf install -y dnsmasq
# systemctl start dnsmasq
# systemctl enable dnsmasq
# systemctl status dnsmasq

There is a sample of a working dnsmasq.conf in the fusion-git directory named copy-to-etc-dnsmasq.conf
first backup the default dnsmasq.conf file
# cp /etc/dnsmasq.conf /etc/dnsmasq-original-conf
Edit the copy-to-etc-dnsmasq.conf file 
# vi copy-to-etc-dnsmasq.conf
edit the listen-address= line to have your IP address
edit the interface=to have your address "output of ip a"
edit the domain= for your base domain
edit the local= for your domain

If you want the Bastion to perform DHCP uncomment the DHCP section and define a range
edit the server= to your upstream dns servers
edit the defining rules for the bastion and HAproxy server 
Note that the OCP cluster api and .apps are required for the cluster to operate the .apps is a wildcard

write and quit the file and copy it to /etc/dnsmasq.conf
perform a # dnsmask --test

there is a sample /etc/hosts file in the fusion-git directory
edit your /etc/hosts file to identify your bastion and lb servers and master1-3 after ip's are assigned
when each coreos node boots you will see the IP address at the command prompt. 
It will also be in the /var/lib/dnsmasq/dnsmasq.leases file if dhcp is assigned by bastion.

If you did not disable the firewall you need to open it for the service
firewall-cmd --add-service=dns --permanent
firewall-cmd --add-service=dhcp --permanent
firewall-cmd --reload

edit your /etc/resolv.conf to include ::1 127.0.0.1 and your Bastion/DNS server address
The upstream DNS servers will be routed via the dnsmasq.conf file
after you edit your /etc/resolv.conf file set it to write protect
# chattr +i /etc/resolv.conf
# systemctl restart dnsmasq

test the dns server forward and backward
# dig bastion
# dig bastion.yourdomain.com
# dig -x 192.168.x.xxx your ip  


Starting the Openshift Cluster Install. 
From the Openshift Cluster Mananger define your parameters for your cluster. 
https://console.redhat.com/openshift/

Select Create Cluster
Select the Data Center Tab
Select Create Cluster
enter a Cluster Name
enter your Domain name
Select your OCP version Fusion currently needs 4.10
Select your CPU Architecture
Select DHCP for nodes or static
Select if you want the drives encrypted or not
Select if you want to add virtualization or not
Select if you want to add Redhat virtualization or not ( I added this later)

This is where you need to inject your ssh public key from the Bastion server.
Click Add hosts to Download the Discovery ISO image.

Generate the Discovery ISO   
Download it and use rufus to burn it to three usb drives (One for each coreos node)
It seems that the DD option of rufus is the most reliable for this. 

On the Dell Server enter the usb drive on the back usb port and boot server. 
Select F-11 to modify boot order. 
Enter Uefi boot menu from bios.
Select boot from usb device at reach usb port.
Boot to CoreOS monitor the Openshift Cluster Mananger until each server reports ready.
rename servers as desired master1 master2 master3... 

As the Servers boot you will see the DHCP address at the coreos prompt. 
Modify your /etc/hosts to identify the FQDN of each server 
and restart dnsmasq
Install the Cluster from the Cluster Manager
When the cluster build is complete you can download the kubeconfig.

I suggest injecting the ssh key with 
ssh -i sshkey -o StrictHostKeyChecking=no core@master1-ip
ssh -o StrictHostKeyChecking=no master1.lbs.com
ssh -o StrictHostKeyChecking=no core@master1.lbs.com
ssh -o StrictHostKeyChecking=no core@master2.lbs.com
ssh -o StrictHostKeyChecking=no core@master3.lbs.com
ssh -o StrictHostKeyChecking=no root@master1.lbs.com
ssh -o StrictHostKeyChecking=no root@lb.lbs.com

if you want to change the passwd for root you can do it with
# sudo su 
# passwd enter enter
# passwd core enter enter

do the other servers if desired
for trouble shooting you can perform 
# sudo journalctl -u agent.service
# sudo journalctl TAG=agent

Two of your servers will process 7 process and one will load 10 processes it will pause until the others finish
When the servers complete step 4 of 7 they will reboot and will boot to the internal drives. 

When everything completes the cluster will be complete. 

Log Into the cluster 
export KUBECONFIG=kubeconfig
oc login https://clustername.domainname:6443 -u kubeadmin -p kubeadmin-pw
you will have ip address's for the api and appssee the wildcard note above.


Install haproxy Load Balancer
# yum install -y haproxy
backup the haproxy original config
# cp /etc/haproxy/haproxy.cfg /etc/haproxy/orig.haproxy.cfg
There is a sample working haproxy config in the fusion-git directory
modifiy it with your cluster information and copy it to 
# cp example-etc-haproxy-haproxy.cfg /etc/haproxy/haproxy.cfg 

restart haproxy 
# systemctl restart haproxy
# systemctl enable haproxy
# systemctl status haproxy

You will need to create another cluster admin user
I suggest using htpasswd
# htpasswd -c -B -b HTPASSWD ocadmin password
# oc adm policy add-cluster-role-to-group cluster-admin mylocaladmins
# oc create secret generis htpass-secret --from-file=htpasswd=/root/HTPASSWD -n openshift-config
# oc login https://api.may10c.lbs.com:6443 -u ocadmin -p password

Install Fusion
https://www.ibm.com/docs/en/storage-fusion/2.4?topic=fusion-installing-spectrum-premises-bare-metal

Adding the IBM Operator Catalog
https://www.ibm.com/docs/en/cloud-paks/1.0?topic=clusters-adding-operator-catalog



