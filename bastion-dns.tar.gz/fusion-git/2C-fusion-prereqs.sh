
# This will install git for github webget to download from a HTML and dnsmasq if the Bastion will be the dns server
echo "Pauseing for 10 Seconds hit ctrl c to escape"
sleep 10 
dnf -y install wget git bind-utils openssh-server dnsmasq haproxy jq grubby

